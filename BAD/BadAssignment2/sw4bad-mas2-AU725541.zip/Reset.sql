-- Disconnect all connections before running. HOMEBOII
DROP DATABASE Bakery;
